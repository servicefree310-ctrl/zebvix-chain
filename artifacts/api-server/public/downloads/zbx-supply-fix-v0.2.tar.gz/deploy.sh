#!/usr/bin/env bash
# Zebvix zbx_supply patch v0.2 — adds pool_seed_wei, pool_reserve_wei
# Fixes circulating to include 10M AMM pool genesis seed.
set -euo pipefail
CHAIN_DIR="${CHAIN_DIR:-/home/zebvix-chain}"
[ -d "$CHAIN_DIR/src" ] || { echo "ERROR: $CHAIN_DIR/src not found. Set CHAIN_DIR=/path/to/zebvix-chain"; exit 1; }
cp -v rpc.rs "$CHAIN_DIR/src/rpc.rs"
echo "[*] Building (release)..."
( cd "$CHAIN_DIR" && cargo build --release --bin zebvix-node )
install -v -m 0755 "$CHAIN_DIR/target/release/zebvix-node" /usr/local/bin/zebvix-node
echo "[OK] Binary updated. Restart your nodes to pick up new RPC fields."
