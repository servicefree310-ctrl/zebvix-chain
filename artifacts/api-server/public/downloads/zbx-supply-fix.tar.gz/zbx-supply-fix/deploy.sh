#!/usr/bin/env bash
# Zebvix supply RPC patch — VPS deploy script
# Adds: premine_wei, burned_wei, circulating_wei to zbx_supply RPC response.
set -euo pipefail

# ─── Edit these 3 paths if your VPS layout is different ──────────────────────
CHAIN_DIR="${CHAIN_DIR:-/root/zebvix-chain}"           # repo root on VPS
RPC_FILE="$CHAIN_DIR/src/rpc.rs"                       # file to patch
NODE_SVCS=("${NODE_SVCS[@]:-zebvix-node-1 zebvix-node-2}")  # systemd units
# ─────────────────────────────────────────────────────────────────────────────

PATCH_SRC="$(dirname "$(readlink -f "$0")")/rpc.rs"

if [[ ! -f "$PATCH_SRC" ]]; then
  echo "ERROR: patched rpc.rs not found at $PATCH_SRC" >&2
  exit 1
fi
if [[ ! -d "$CHAIN_DIR" ]]; then
  echo "ERROR: chain dir $CHAIN_DIR not found. Set CHAIN_DIR=/path/to/zebvix-chain" >&2
  exit 1
fi

echo "==> 1/5  Backing up old rpc.rs"
cp -v "$RPC_FILE" "$RPC_FILE.bak.$(date +%s)"

echo "==> 2/5  Installing patched rpc.rs"
cp -v "$PATCH_SRC" "$RPC_FILE"

echo "==> 3/5  Building release binary (this takes ~2-5 min)"
cd "$CHAIN_DIR"
cargo build --release --bin zebvix-node

BIN_OUT="$CHAIN_DIR/target/release/zebvix-node"
if [[ ! -x "$BIN_OUT" ]]; then
  echo "ERROR: build did not produce $BIN_OUT" >&2
  exit 1
fi

echo "==> 4/5  Installing binary to /usr/local/bin and restarting nodes"
install -m 0755 "$BIN_OUT" /usr/local/bin/zebvix-node
for svc in "${NODE_SVCS[@]}"; do
  echo "    restarting $svc"
  systemctl restart "$svc" || echo "    (warning: $svc not managed by systemd, skipping)"
done

echo "==> 5/5  Verifying new RPC fields"
sleep 3
RPC_URL="${RPC_URL:-http://127.0.0.1:8080}"
RESP="$(curl -s -X POST "$RPC_URL" -H 'content-type: application/json' \
  -d '{"jsonrpc":"2.0","id":1,"method":"zbx_supply","params":[]}' || true)"
echo "$RESP" | head -c 600; echo
if echo "$RESP" | grep -q 'circulating_wei'; then
  echo
  echo "✅ SUCCESS — circulating_wei is live on the chain."
else
  echo
  echo "⚠️  Patch built and binary swapped, but circulating_wei not visible yet."
  echo "   Check that the node restarted: systemctl status ${NODE_SVCS[*]}"
fi
