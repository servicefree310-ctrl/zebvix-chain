B.11 v3 — fixes rpc.rs:378 .into() ambiguity + state.rs:940 borrow-checker.
