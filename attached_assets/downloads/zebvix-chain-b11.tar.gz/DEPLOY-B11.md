# Zebvix Chain — Phase B.11 Deploy (secp256k1 / ETH compat)

**BREAKING.** Wire format and address derivation changed. **Old chain data
must be wiped.** All old wallets become unusable.

## What changed (high level)

- Crypto: **Ed25519 → secp256k1 (ECDSA)**.
- Address: now **ETH-standard** = `keccak256(uncompressed_pub[1..])[12..]`.
  → One ETH private key (MetaMask) derives the **same address** on Zebvix.
- Pubkey on the wire: 32B → **33B** (compressed SEC1).
- Signature: 64B compact `r||s` (low-S, RFC6979 deterministic) — same length.
- New deterministic founder/admin (rotate to your own ETH key in production):
  - sk      = `0xa8674e60d95ec1fa2b37f264b01b8407d2fbb0789bd836382472d181973ebbf8`
              (= `keccak256("zebvix-genesis-founder-v1")`)
  - pubC33  = `0x035a3d7a0a8ce0607fa8a2ac3f36d4239ad9f582ca044a125d262f42eff3bcf9d3`
  - address = `0x40907000ac0a1a73e4cd89889b4d7ee8980c0315`
  - Paste the sk hex into MetaMask → you get the same address.

## Files in this tarball (drop-in replacements)

```
zebvix-chain/Cargo.toml                  # ed25519-dalek removed, k256 added
zebvix-chain/src/crypto.rs               # full rewrite (ETH test vector inside)
zebvix-chain/src/types.rs                # Validator.pubkey [u8;33] + hex_array_33
zebvix-chain/src/transaction.rs          # SignedTx.pubkey [u8;33]
zebvix-chain/src/staking.rs              # ValidatorState.pubkey [u8;33]
zebvix-chain/src/vote.rs                 # Vote.pubkey [u8;33]
zebvix-chain/src/consensus.rs            # test stub fix
zebvix-chain/src/main.rs                 # keyfile / parse_pubkey_hex 33B
zebvix-chain/src/bin/zbx.rs              # same
zebvix-chain/src/tokenomics.rs           # FOUNDER_PUBKEY_HEX + ADMIN_ADDRESS_HEX
```

## Deploy on srv1266996 (PowerShell on Windows → ssh)

```bash
# 0. Copy the tarball to the VPS:
#    (from your Windows box)
#    scp zebvix-chain-b11.tar.gz root@93.127.213.192:/root/

# 1. SSH in
ssh root@93.127.213.192

# 2. Backup current source + chain data
cd ~/zebvix-chain
git stash || true
cp -r src src.bak-prebll-$(date +%s)
cp Cargo.toml Cargo.toml.bak-prebll
# back up old chain data dirs (one per node)
for d in ~/.zebvix-node1 ~/.zebvix-node2; do
  [ -d "$d" ] && mv "$d" "$d.bak-prebll-$(date +%s)"
done

# 3. Stop both nodes (adjust if you use systemd / pm2 / tmux):
pkill -f zebvix-chain || true
pkill -f 'zbx ' || true

# 4. Unpack the new sources OVER the existing tree
cd ~
tar xzf zebvix-chain-b11.tar.gz   # extracts into ./zebvix-chain/

# 5. Build release
cd ~/zebvix-chain
cargo build --release             # ~2-5 min on srv1266996

# 6. Re-init each node (chain data was wiped in step 2).
#    The genesis validator (founder, deterministic) is seeded automatically
#    by main.rs:cmd_init from FOUNDER_PUBKEY_HEX in tokenomics.rs.
~/zebvix-chain/target/release/zbx keygen --out ~/zebvix-keys/node1.json --force
~/zebvix-chain/target/release/zebvix-chain init \
   --validator-key ~/zebvix-keys/node1.json \
   --data-dir ~/.zebvix-node1 \
   --chain-id 7878

# (repeat for node2 if you run a 2-node setup)

# 7. Start node1
nohup ~/zebvix-chain/target/release/zebvix-chain run \
   --validator-key ~/zebvix-keys/node1.json \
   --data-dir ~/.zebvix-node1 \
   --rpc-listen 0.0.0.0:8545 \
   > ~/zebvix-node1.log 2>&1 &
disown

# 8. Verify chain alive
curl -s -X POST http://127.0.0.1:8545 \
  -H 'content-type: application/json' \
  --data '{"jsonrpc":"2.0","id":1,"method":"zbx_chainId","params":[]}'
# → {"jsonrpc":"2.0","id":1,"result":7878}

curl -s -X POST http://127.0.0.1:8545 \
  -H 'content-type: application/json' \
  --data '{"jsonrpc":"2.0","id":2,"method":"zbx_getValidator","params":["0x40907000ac0a1a73e4cd89889b4d7ee8980c0315"]}'
# → result should show pubkey starting with 0x035a3d7a... (33B founder)

# 9. Test ETH address compat (MetaMask):
#    - Open MetaMask → Account menu → Import account → paste:
#      0xa8674e60d95ec1fa2b37f264b01b8407d2fbb0789bd836382472d181973ebbf8
#    - The imported account address must show as
#      0x40907000ac0a1a73e4cd89889b4d7ee8980c0315
#    - Same address derived from the same sk on Zebvix → done.
```

## Rollback

If anything breaks:
```bash
cd ~/zebvix-chain
rm -rf src
mv src.bak-prebll-* src
mv Cargo.toml.bak-prebll Cargo.toml
cargo build --release
# restore old chain data from .bak-prebll-* dirs (or re-init under old code)
```

## Why a clean wipe?

The on-disk validator records (sled) embed `[u8; 32]` ed25519 pubkeys via
serde+bincode. The new binary reads the same bytes as `[u8; 33]` and will
decode-fail on the very first block apply. There is no transparent migration.

